from __future__ import annotations
import json, hashlib, zipfile
from pathlib import Path
from importlib.resources import files
from datetime import datetime, timezone
from typing import Any

KINDS = "DIKWP"


def load_data(name: str) -> Any:
    return json.loads(files("regenloop").joinpath("data", name).read_text(encoding="utf-8"))


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def summary() -> dict:
    dims = load_data("dimensions.json")
    return {
        "system": "REGENLOOP",
        "version": "1.0.0",
        "mode": "MESH84_REGENLOOP_PERSONAL_ECOLOGICAL_UPGRADE",
        "dimensions": len(dims),
        "true_values": len(load_data("true_values.json")),
        "ai_roles": len(load_data("ai_roles.json")),
        "invasive_signals": len(load_data("invasive_signals.json")),
        "shocks": len(load_data("shocks.json")),
        "core_digest": digest({
            "dimensions": dims,
            "values": load_data("true_values.json"),
            "cycle": load_data("cycle_days.json"),
            "shocks": load_data("shocks.json"),
        }),
        "boundary": "Ecological restoration is a systems-design metaphor, not a clinical or biological equivalence."
    }


def _profile_dimension(profile: dict, dim_id: str) -> dict:
    return profile.get("dimensions", {}).get(dim_id, {"status": "stable", "evidence": "", "urgency": 0})


def diagnose(profile: dict) -> dict:
    dims = load_data("dimensions.json")
    status_defs = load_data("status_defs.json")
    constraints = profile.get("constraints", {})
    energy = constraints.get("energy_level", "medium")
    minutes = int(constraints.get("minutes_per_day", 30))
    support = constraints.get("support_network", "thin")
    candidates = []
    for d in dims:
        p = _profile_dimension(profile, d["id"])
        status = p.get("status", "stable")
        severity = status_defs.get(status, status_defs["stable"])["severity"]
        urgency = int(p.get("urgency", 0))
        leverage = int(d.get("leverage", len(d.get("cascade", []))))
        feasibility = 1
        if energy == "low" and d["id"] in {"vitality", "attention", "agency"}:
            feasibility += 2
        if minutes < 30 and d["id"] in {"vitality", "attention", "agency"}:
            feasibility += 1
        if support == "isolated" and d["id"] == "relationships":
            feasibility += 2
        priority = severity * 10 + urgency * 4 + leverage + feasibility
        candidates.append({
            "dimension_id": d["id"], "name_cn": d["name_cn"], "status": status,
            "evidence": p.get("evidence", ""), "cascade": d.get("cascade", []),
            "intervention_cn": d["intervention_cn"], "priority_internal": priority,
            "reason_cn": f"状态为{status_defs.get(status,{}).get('label_cn',status)}；可联动 {len(d.get('cascade',[]))} 个维度；紧迫度 {urgency}/3。"
        })
    candidates.sort(key=lambda x: (-x["priority_internal"], x["dimension_id"]))
    keystone = candidates[0]
    visible_candidates = [{k:v for k,v in x.items() if k != "priority_internal"} for x in candidates[:4]]
    vector = {}
    for d in dims:
        vector[d["id"]] = _profile_dimension(profile,d["id"]).get("status","stable")
    return {
        "profile_id": profile.get("profile_id", "anonymous"),
        "keystone": {k:v for k,v in keystone.items() if k != "priority_internal"},
        "alternatives": visible_candidates[1:],
        "habitat_vector": vector,
        "selected_values": profile.get("selected_values", []),
        "claim_boundary": "This is a deterministic planning aid, not medical, psychological, employment, or financial diagnosis."
    }


def build_cycle(profile: dict, days: int = 7) -> dict:
    dx = diagnose(profile)
    templates = load_data("cycle_days.json")
    roles = {x["id"]:x for x in load_data("ai_roles.json")}
    constraints = profile.get("constraints", {})
    minutes = max(10, min(120, int(constraints.get("minutes_per_day",30))))
    cycle = []
    for item in templates[:max(1,min(days,7))]:
        role = roles[item["ai_role"]]
        cycle.append({
            **item,
            "time_budget_minutes": minutes,
            "keystone_dimension": dx["keystone"]["dimension_id"],
            "keystone_action": dx["keystone"]["intervention_cn"] if item["day"] in {3,4,5} else None,
            "ai_role_name_cn": role["name_cn"],
            "ai_boundary_cn": role["human_gate_cn"],
        })
    return {
        "cycle_id": f"{profile.get('profile_id','anonymous')}-regen-001",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "keystone": dx["keystone"],
        "days": cycle,
        "minimum_human_conversions": ["一次离线实践","一次真人反馈","一个可验证作品或决定","一次本地导出/复盘"],
        "automation_boundary": "AI may catalyse, map, challenge, tutor, edit, connect, or archive; it may not replace the human conversion step.",
        "selected_values": profile.get("selected_values", []),
    }


def review_cycle(review: dict) -> dict:
    changes = review.get("dimension_changes", {})
    down = [k for k,v in changes.items() if v == "DOWN"]
    up = [k for k,v in changes.items() if v == "UP"]
    critical_down = [k for k in down if k in {"vitality","agency","relationships","optionality"}]
    actions = review.get("human_actions", [])
    copy_ratio = float(review.get("ai_copy_ratio",0))
    flags = []
    if not actions: flags.append("NO_HUMAN_CONVERSION")
    if not review.get("real_person_feedback",False): flags.append("NO_REAL_PERSON_FEEDBACK")
    if not review.get("artifact_created",False): flags.append("NO_VERIFIABLE_ARTIFACT")
    if copy_ratio > 0.7: flags.append("HIGH_AI_COPY_RATIO")
    if critical_down: flags.append("CRITICAL_DIMENSION_DEPLETION")
    if critical_down or (copy_ratio > 0.7 and len(up) < 3):
        state = "EXTRACTIVE_LOOP"
    elif not actions or (not review.get("artifact_created") and not review.get("real_person_feedback")):
        state = "DORMANT_LOOP"
    elif len(up) >= 4 and not down and review.get("artifact_created") and review.get("real_person_feedback"):
        state = "REGENERATIVE_LOOP"
    else:
        state = "MIXED_LOOP"
    return {
        "cycle_id": review.get("cycle_id","unknown"), "state": state,
        "up": up, "down": down, "flags": flags,
        "next_action_cn": {
            "REGENERATIVE_LOOP":"保留有效关系，降低AI替代比例，并把成果种入下一循环。",
            "MIXED_LOOP":"只保留产生真实增益的部分，修复下降维度后再扩张。",
            "DORMANT_LOOP":"停止继续生成文本，先完成一个离线行动或真人反馈。",
            "EXTRACTIVE_LOOP":"立即止损；优先恢复身体、主体性、关系或未来选择。"
        }[state],
        "boundary":"No total life score is produced. Monetary output cannot compensate for critical depletion."
    }


def run_shock(profile: dict, shock_id: str) -> dict:
    shocks = {x["id"]:x for x in load_data("shocks.json")}
    if shock_id not in shocks:
        raise KeyError(shock_id)
    dx = diagnose(profile)
    sh = shocks[shock_id]
    return {
        "shock": sh,
        "current_keystone": dx["keystone"],
        "first_24_hours": sh["response_cn"][:2],
        "next_7_days": sh["response_cn"],
        "hard_boundary":"No identity, age, jurisdiction, safety, or institutional control bypass is provided.",
    }


def init_vault(path: str, profile_id: str) -> dict:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists() and p.stat().st_size:
        raise FileExistsError(path)
    event = {"seq":1,"time":datetime.now(timezone.utc).isoformat(),"type":"VAULT_INIT","profile_id":profile_id,"payload":{},"prev":"0"*64}
    event["hash"] = hashlib.sha256(canonical(event)).hexdigest()
    p.write_text(json.dumps(event,ensure_ascii=False)+"\n",encoding="utf-8")
    return event


def append_vault(path: str, event_type: str, payload: dict) -> dict:
    p = Path(path)
    rows = [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
    prev = rows[-1]["hash"]
    event = {"seq":len(rows)+1,"time":datetime.now(timezone.utc).isoformat(),"type":event_type,"payload":payload,"prev":prev}
    event["hash"] = hashlib.sha256(canonical(event)).hexdigest()
    with p.open("a",encoding="utf-8") as f: f.write(json.dumps(event,ensure_ascii=False)+"\n")
    return event


def verify_vault(path: str) -> dict:
    rows = [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]
    prev = "0"*64
    for i,row in enumerate(rows,1):
        if row.get("seq") != i or row.get("prev") != prev:
            return {"valid":False,"at":i,"reason":"sequence_or_prev"}
        h = row.get("hash")
        obj = dict(row); obj.pop("hash",None)
        if hashlib.sha256(canonical(obj)).hexdigest() != h:
            return {"valid":False,"at":i,"reason":"hash"}
        prev = h
    return {"valid":True,"events":len(rows),"root_hash":prev}


def export_vault(path: str, out_zip: str) -> dict:
    v = verify_vault(path)
    if not v["valid"]: raise ValueError(v)
    p = Path(path); out = Path(out_zip)
    manifest = {"file":p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"verification":v}
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        z.write(p,p.name)
        z.writestr("VAULT_MANIFEST.json",json.dumps(manifest,ensure_ascii=False,indent=2))
    return {"zip":str(out),"manifest":manifest}


def selftest() -> dict:
    errors=[]
    s=summary()
    if s["dimensions"] != 9: errors.append("dimensions")
    if s["true_values"] != 10: errors.append("values")
    if s["shocks"] != 10: errors.append("shocks")
    sample = {
      "profile_id":"t", "dimensions":{"attention":{"status":"depleted","urgency":3}},
      "constraints":{"minutes_per_day":30,"energy_level":"medium","support_network":"thin"}, "selected_values":["truth"]
    }
    if not diagnose(sample).get("keystone"): errors.append("diagnose")
    if len(build_cycle(sample)["days"]) != 7: errors.append("cycle")
    rv = review_cycle({"cycle_id":"x","human_actions":["a"],"dimension_changes":{"attention":"UP","agency":"UP","craft":"UP","relationships":"UP"},"artifact_created":True,"real_person_feedback":True,"ai_copy_ratio":0.2})
    if rv["state"] != "REGENERATIVE_LOOP": errors.append("review")
    return {"passed":not errors,"errors":errors,"checks":6,"summary":s}
