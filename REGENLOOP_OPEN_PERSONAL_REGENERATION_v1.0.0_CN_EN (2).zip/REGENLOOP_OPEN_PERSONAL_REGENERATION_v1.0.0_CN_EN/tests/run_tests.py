import json, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'src'))
from regenloop.core import *

t=[]
def check(n,x): t.append((n,bool(x)))
check('summary',summary()['dimensions']==9)
p=json.loads((root/'examples/profiles/exhausted_creator.json').read_text(encoding='utf-8'))
d=diagnose(p)
check('diagnose',d['keystone']['dimension_id'] in {x['id'] for x in load_data('dimensions.json')})
check('plan',len(build_cycle(p)['days'])==7)
r=json.loads((root/'examples/reviews/regenerative_cycle.json').read_text(encoding='utf-8'))
check('review',review_cycle(r)['state']=='REGENERATIVE_LOOP')
check('shock',run_shock(p,'SH_AI_LOSS')['shock']['id']=='SH_AI_LOSS')
with tempfile.TemporaryDirectory() as td:
    v=Path(td)/'vault.jsonl'; z=Path(td)/'vault.zip'
    init_vault(str(v),'p1'); append_vault(str(v),'NOTE',{'x':1})
    check('vault_verify',verify_vault(str(v))['valid'])
    check('vault_export',Path(export_vault(str(v),str(z))['zip']).exists())
check('selftest',selftest()['passed'])
for n,v in t: print(('PASS' if v else 'FAIL'),n)
print(sum(v for _,v in t),'passed,',sum(not v for _,v in t),'failed')
raise SystemExit(0 if all(v for _,v in t) else 1)
