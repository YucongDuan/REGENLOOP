# Security

REGENLOOP is local-first. Do not store secrets, medical records, legal privileged material, or third-party personal data in public profiles. Report vulnerabilities through a private channel before disclosure.
