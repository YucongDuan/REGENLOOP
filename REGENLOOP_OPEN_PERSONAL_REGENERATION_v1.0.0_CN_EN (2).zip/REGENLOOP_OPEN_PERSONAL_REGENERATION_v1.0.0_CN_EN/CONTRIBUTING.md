# Contributing

Contributions are welcome for field reports, source corrections, new lawful shock scenarios, accessibility, translations, and independently tested cycle templates. Do not submit personality scores, secret social rankings, or methods to bypass institutional or legal safeguards.
