# REGENLOOP 开放原则 / Open Principles

1. AI is a catalyst, not a permanent master.
2. One keystone loop is better than fifty disconnected optimisations.
3. Human conversion is mandatory: practice, relationship, artifact, or continuity.
4. No total life score; critical depletion cannot be offset by money or output.
5. Diversity is resilience: multiple sources, models, relationships, skills, and paths.
6. Contribution requires reciprocity; open does not mean unlimited free extraction.
7. Every cycle must be correctable and exportable.
8. The system may help people adapt to restrictions, but never bypass age, identity, safety, institutional, or legal controls.
