# Source Ledger

- **SRC_VIDEO** [百度视频：怀俄明州将500头野生美洲野牛放归原住民土地……](https://mbd.baidu.com/newspage/data/videolanding?nid=sv_3138703022235575149&sourceFrom=share) — 只作为生态循环启发。标题中的“500头”未被本系统当作事实依据。
- **SRC_WIND_RIVER** [Jason Baldes is restoring the keystone bison on Tribal lands](https://www.nationalgeographic.com/impact/article/jason-baldes-explorer-story) — Wind River于2016年先放归10头野牛；2026年报道估计两个部族牛群约350头，并强调生态、文化和社区修复。
- **SRC_USGS** [USGS: Ecology of Badlands National Park](https://www.usgs.gov/geology-and-ecology-of-national-parks/ecology-badlands-national-park) — 野牛放牧区域植物多样性更高；打滚形成的洼地可蓄水并支持其他生物。
- **SRC_PNAS** [Ratajczak et al. (2022), Reintroducing bison results in long-running and resilient increases in grassland diversity](https://www.pnas.org/doi/10.1073/pnas.2210433119) — 长期研究报告野牛回归显著提高原生植物丰富度，增益持续多年并经受极端干旱。
- **SRC_CHI** [Lee et al. (2025), The Impact of Generative AI on Critical Thinking](https://doi.org/10.1145/3706598.3713778) — 知识工作者调查显示，对GenAI信心更高与较少批判性思考相关；AI也把思考转向核验、整合和任务监督。
- **SRC_CREATIVITY** [Doshi & Hauser (2024), Generative AI enhances individual creativity but reduces the collective diversity of novel content](https://doi.org/10.1126/sciadv.adn5290) — AI可提高个体创意产出，但AI辅助作品之间更相似，提示个人增益与集体多样性之间的张力。
