# REGENLOOP｜再生环

**AI时代个人再生循环与人机共生升级系统**

> 不是让AI替你活，而是让你的能力、关系和贡献重新长出来。

版本：1.0.0  
模式：`MESH84_REGENLOOP_PERSONAL_ECOLOGICAL_UPGRADE`  
快照：2026-08-19  
许可证：Apache-2.0

## 一句话机制

生态恢复不一定从“修复每一个物种”开始，而可能从恢复一个能改变水、土、植被和物种关系的关键功能开始。REGENLOOP把这个思想转化为个人升级：先识别一个能够联动多个维度的**关键瓶颈**，再让AI只承担催化、地图、反方、教练、编辑、连接或档案角色，最后强制转化为人的理解、身体行动、真实关系、作品和未来选择。

## 快速运行

```bash
python dist/RegenLoop.pyz summary
python dist/RegenLoop.pyz diagnose examples/profiles/exhausted_creator.json
python dist/RegenLoop.pyz plan examples/profiles/exhausted_creator.json --out cycle.json
python dist/RegenLoop.pyz review examples/reviews/regenerative_cycle.json
python dist/RegenLoop.pyz shock examples/profiles/career_transition.json SH_AI_LOSS
python dist/RegenLoop.pyz selftest
```

直接打开 `site/index.html` 即可离线使用。

## 关键边界

- 生态恢复是系统设计隐喻，不是把人的心理等同于草原生态。
- 本系统不是医疗、心理、就业、法律或投资诊断。
- 不产生“人生总分”。金钱、产出和用户满意不能抵消身体、主体性、关系和未来选择的枯竭。
- AI必须产生至少一次“人类转换”：离线实践、真人反馈、可验证作品或本地连续性记录。
